package com.gcu.business;

import java.util.List;

import com.gcu.model.BlogModel;

public interface BlogsBusinessServiceInterface {
	public void test();
	public List<BlogModel> getBlogs();
}
