package com.gcu.business;

import java.util.List;

import com.gcu.model.SignUpModel;

public interface UserServiceInterface {
	public void test();
	public List<SignUpModel> getUsers();
}
